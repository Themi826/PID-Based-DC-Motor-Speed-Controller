// ============================================================
// PID DC Motor Speed Control  –  with WiFi Dashboard
// ESP32 DevKit + L298N + DC Motor with Encoder
// Arduino ESP32 Core v3.x Compatible
// ──────────────────────────────────────────────────────────────
// STA MODE – connects to an existing WiFi network (e.g. school)
// ============================================================

#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>   // arduinoWebSockets by Markus Sattler
#include "html_page.h"

// ─────────────── WiFi STA credentials ───────────
// *** CHANGE THESE to match your school WiFi ***
const char* wifi_ssid     = "Oppo A12";
const char* wifi_password = "themi2003";

// ─────────────── Server objects ─────────────────
WebServer          httpServer(80);
WebSocketsServer   wsServer(81);

// --- Pin Definitions ---
#define ENA_PIN     25
#define IN1_PIN     26
#define IN2_PIN     27
#define ENCODER_A   34
#define ENCODER_B   35

// --- Encoder Settings ---
#define PPR         200 // Change to match your encoder

// --- PID Parameters ---
float Kp = 1.2;
float Ki = 0.10;
float Kd = 0.05;

// --- Setpoint ---
float setpoint = 150.0;  // Target RPM

// --- PID Variables ---
float actualSpeed  = 0.0;
float error        = 0.0;
float prevError    = 0.0;
float integral     = 0.0;
float derivative   = 0.0;
float pidOutput    = 0.0;
float pidOutput_prev = 0.0;

// --- Anti-windup limits ---
float integralMax  =  200.0;
float integralMin  = -200.0;

// --- Encoder ---
volatile long encoderCount = 0;

// --- Timing ---
unsigned long lastTime = 0;
const unsigned long sampleTime = 100; // ms
unsigned long lastIpPrint = 0;
unsigned long lastPidPrint = 0;

// ============================================================
// INTERRUPT
// ============================================================
void IRAM_ATTR encoderISR() {
  if (digitalRead(ENCODER_B) == HIGH) {
    encoderCount++;
  } else {
    encoderCount--;
  }
}

// ============================================================
// Broadcast JSON over WebSocket
// ============================================================
void sendData() {
  String json = "{";
  json += "\"setpoint\":" + String(setpoint,   2) + ",";
  json += "\"speed\":"    + String(actualSpeed, 2) + ",";
  json += "\"output\":"   + String(pidOutput,   2);
  json += "}";
  wsServer.broadcastTXT(json);
}

// ============================================================
// WebSocket event handler
// ============================================================
void onWsEvent(uint8_t num, WStype_t type, uint8_t* payload, size_t len) {
  if (type == WStype_TEXT) {
    String msg = String((char*)payload);
    int c1 = msg.indexOf(',');
    int c2 = msg.indexOf(',', c1 + 1);
    int c3 = msg.indexOf(',', c2 + 1);
    if (c1 > 0 && c2 > c1 && c3 > c2) {
      Kp = atof(msg.substring(0, c1).c_str());
      Ki = atof(msg.substring(c1 + 1, c2).c_str());
      Kd = atof(msg.substring(c2 + 1, c3).c_str());
      setpoint = atof(msg.substring(c3 + 1).c_str());
      integral = 0;  // reset integral to avoid windup carryover
      pidOutput_prev = 0;
      Serial.printf("[WS] Kp=%.3f  Ki=%.3f  Kd=%.4f  SP=%.1f\n",
                    Kp, Ki, Kd, setpoint);
    }
  }
}

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);
  delay(500);

  // --- Motor & Encoder ---
  pinMode(IN1_PIN, OUTPUT);
  pinMode(IN2_PIN, OUTPUT);
  pinMode(ENCODER_A, INPUT_PULLUP);
  pinMode(ENCODER_B, INPUT_PULLUP);

  // Motor direction: forward
  digitalWrite(IN1_PIN, HIGH);
  digitalWrite(IN2_PIN, LOW);

  // ESP32 Core v3.x PWM setup
  ledcAttach(ENA_PIN, 1000, 8);
  ledcWrite(ENA_PIN, 0);

  // Encoder interrupt
  attachInterrupt(digitalPinToInterrupt(ENCODER_A), encoderISR, RISING);

  // --- WiFi STA (connect to existing network) ---
  WiFi.disconnect(true);
  delay(100);
  WiFi.mode(WIFI_STA);
  WiFi.begin(wifi_ssid, wifi_password);

  Serial.print("\n[WiFi] Connecting to: ");
  Serial.println(wifi_ssid);

  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 40) {
    delay(500);
    Serial.print(".");
    attempts++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n[WiFi] CONNECTED!");
    Serial.print("[WiFi] IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("[WiFi] Dashboard: http://");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\n[WiFi] FAILED to connect!");
    Serial.println("[WiFi] Check SSID/password and try again.");
    Serial.println("[WiFi] Continuing anyway – motor PID still runs.");
  }

  // --- HTTP server ---
  httpServer.on("/", []() {
    httpServer.send_P(200, "text/html", INDEX_HTML);
  });
  httpServer.begin();
  Serial.println("[HTTP] Server on port 80");

  // --- WebSocket server ---
  wsServer.begin();
  wsServer.onEvent(onWsEvent);
  Serial.println("[WS]   Server on port 81");

  lastTime = millis();
  Serial.println("Setpoint,Speed,Output");
}

// ============================================================
// LOOP
// ============================================================
void loop() {
  httpServer.handleClient();
  wsServer.loop();

  // Reconnect if WiFi drops
  if (WiFi.status() != WL_CONNECTED) {
    static unsigned long lastReconnect = 0;
    if (millis() - lastReconnect >= 10000) {
      lastReconnect = millis();
      Serial.println("[WiFi] Disconnected – attempting reconnect...");
      WiFi.disconnect();
      WiFi.begin(wifi_ssid, wifi_password);
    }
  }

  // Periodic status
  if (millis() - lastIpPrint >= 20000) {
    lastIpPrint = millis();
    Serial.print("[WiFi] IP: ");
    Serial.print(WiFi.localIP());
    Serial.print("  Status: ");
    Serial.println(WiFi.status() == WL_CONNECTED ? "CONNECTED" : "DISCONNECTED");
  }

  // Print PID values every 3 seconds
  if (millis() - lastPidPrint >= 3000) {
    lastPidPrint = millis();
    Serial.printf("[PID] Kp=%.3f  Ki=%.4f  Kd=%.4f  SP=%.1f  Speed=%.1f  Out=%.1f\n",
                  Kp, Ki, Kd, setpoint, actualSpeed, pidOutput);
  }

  unsigned long currentTime = millis();
  unsigned long elapsed = currentTime - lastTime;

  // Accept PID values from Serial too
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    int c1 = input.indexOf(',');
    int c2 = input.indexOf(',', c1 + 1);
    int c3 = input.indexOf(',', c2 + 1);
    if (c1 > 0 && c2 > c1 && c3 > c2) {
      Kp = atof(input.substring(0, c1).c_str());
      Ki = atof(input.substring(c1 + 1, c2).c_str());
      Kd = atof(input.substring(c2 + 1, c3).c_str());
      setpoint = atof(input.substring(c3 + 1).c_str());
      integral = 0;
      pidOutput_prev = 0;
      Serial.printf("[SER] Kp=%.3f  Ki=%.3f  Kd=%.4f  SP=%.1f\n",
                    Kp, Ki, Kd, setpoint);
    }
  }

  if (elapsed >= sampleTime) {
    lastTime = currentTime;

    // Read encoder count safely
    noInterrupts();
    long count = encoderCount;
    encoderCount = 0;
    interrupts();

    // Calculate RPM with fixed dt
    const float dt = 0.1;  // 100 ms = 0.1 s
    float newRPM = abs(((float)count * 60.0) / (PPR * dt));

    // Clamp unrealistic spikes
    if (newRPM > 500) newRPM = actualSpeed;

    // Low-pass filter
    actualSpeed = 0.7 * actualSpeed + 0.3 * newRPM;

    // PID
    error = setpoint - actualSpeed;
    integral += error * dt;
    integral = constrain(integral, integralMin, integralMax);
    derivative = (error - prevError) / dt;

    pidOutput = (Kp * error) + (Ki * integral) + (Kd * derivative);

    // Deadband – prevent jitter near setpoint
    if (abs(error) < 5) {
      pidOutput = 0;
    }

    // Clamp minimum PWM (motor needs kick)
    if (pidOutput > 0 && pidOutput < 60) {
      pidOutput = 60;
    }

    // Output smoothing
    pidOutput = 0.7 * pidOutput_prev + 0.3 * pidOutput;
    pidOutput_prev = pidOutput;

    // Apply PWM
    pidOutput = constrain(pidOutput, 0, 255);
    ledcWrite(ENA_PIN, (int)pidOutput);

    // Send to WebSocket dashboard
    sendData();

    // Serial Plotter output
    Serial.print(setpoint);
    Serial.print(",");
    Serial.print(actualSpeed);
    Serial.print(",");
    Serial.println(pidOutput);

    prevError = error;
  }
}
