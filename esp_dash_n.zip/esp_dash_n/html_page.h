#pragma once
#include <Arduino.h>

const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ESP32 PID Dashboard</title>

  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      background: #0f172a;
      color: #e2e8f0;
      min-height: 100vh;
    }

    .container {
      max-width: 960px;
      margin: auto;
      padding: 20px;
    }

    h1 {
      color: #38bdf8;
      margin-bottom: 6px;
      font-size: 1.5rem;
    }

    .status {
      font-size: 0.85rem;
      color: #facc15;
      margin-bottom: 16px;
    }

    .card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 10px;
      padding: 16px;
      margin-bottom: 16px;
    }

    .card h2 {
      color: #94a3b8;
      font-size: 0.95rem;
      margin-bottom: 12px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    /* Live values row */
    .live-row {
      display: flex;
      gap: 12px;
    }

    .live-box {
      flex: 1;
      background: #0f172a;
      border: 1px solid #334155;
      border-radius: 8px;
      padding: 12px;
      text-align: center;
    }

    .live-box .label {
      font-size: 0.75rem;
      color: #64748b;
      text-transform: uppercase;
      margin-bottom: 4px;
    }

    .live-box .value {
      font-size: 1.6rem;
      font-weight: bold;
      font-family: 'Consolas', monospace;
    }

    .live-box.sp .value { color: #facc15; }
    .live-box.speed .value { color: #22c55e; }
    .live-box.out .value { color: #38bdf8; }

    /* PID inputs - white background */
    .pid-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr;
      gap: 10px;
      align-items: end;
    }

    .pid-field label {
      display: block;
      font-size: 0.78rem;
      color: #94a3b8;
      margin-bottom: 4px;
    }

    .pid-field input {
      width: 100%;
      padding: 8px 10px;
      border: 1px solid #cbd5e1;
      border-radius: 6px;
      background: #ffffff;
      color: #1e293b;
      font-size: 0.95rem;
      font-family: 'Consolas', monospace;
      outline: none;
    }

    .pid-field input:focus {
      border-color: #38bdf8;
      box-shadow: 0 0 0 2px rgba(56,189,248,0.3);
    }

    .btn-row {
      display: flex;
      gap: 8px;
      margin-top: 12px;
    }

    button {
      flex: 1;
      padding: 10px 16px;
      border: none;
      border-radius: 8px;
      font-size: 0.85rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }

    .btn-send {
      background: #38bdf8;
      color: #020617;
    }
    .btn-send:hover { background: #0ea5e9; }

    .btn-preset {
      background: #334155;
      color: #cbd5e1;
    }
    .btn-preset:hover { background: #475569; }

    /* Chart - WHITE background */
    .chart-wrap {
      position: relative;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      overflow: hidden;
    }

    canvas {
      display: block;
      width: 100%;
      height: 320px;
    }

    .legend {
      display: flex;
      gap: 18px;
      justify-content: flex-end;
      padding: 8px 14px;
      font-size: 0.8rem;
      color: #334155;
      background: #f8fafc;
      border-bottom: 1px solid #e2e8f0;
    }

    .legend span::before {
      content: '';
      display: inline-block;
      width: 16px;
      height: 3px;
      margin-right: 5px;
      vertical-align: middle;
      border-radius: 2px;
    }

    .legend .sp::before  { background: #d97706; }
    .legend .spd::before { background: #059669; }

    /* Serial log */
    .log-box {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 10px;
      height: 120px;
      overflow-y: auto;
      font-family: 'Consolas', monospace;
      font-size: 0.78rem;
      color: #334155;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>ESP32 PID Motor Dashboard</h1>
    <p class="status" id="status">Connecting...</p>

    <!-- Live Values -->
    <div class="card">
      <h2>Live Values</h2>
      <div class="live-row">
        <div class="live-box sp">
          <div class="label">Setpoint</div>
          <div class="value" id="setpointVal">-</div>
        </div>
        <div class="live-box speed">
          <div class="label">Speed RPM</div>
          <div class="value" id="speedVal">-</div>
        </div>
        <div class="live-box out">
          <div class="label">PWM Output</div>
          <div class="value" id="outputVal">-</div>
        </div>
      </div>
    </div>

    <!-- PID Tuning -->
    <div class="card">
      <h2>PID Tuning</h2>
      <div class="pid-grid">
        <div class="pid-field">
          <label>Kp</label>
          <input type="text" id="kp" value="1.2">
        </div>
        <div class="pid-field">
          <label>Ki</label>
          <input type="text" id="ki" value="0.10">
        </div>
        <div class="pid-field">
          <label>Kd</label>
          <input type="text" id="kd" value="0.05">
        </div>
        <div class="pid-field">
          <label>Setpoint RPM</label>
          <input type="text" id="sp" value="150">
        </div>
      </div>
      <div class="btn-row">
        <button class="btn-send" onclick="sendPID()">Send PID + Setpoint</button>
        <button class="btn-preset" onclick="setPreset(1.0,0.15,0.05,100)">Stable 100</button>
        <button class="btn-preset" onclick="setPreset(1.0,0.15,0.05,150)">Try 150</button>
        <button class="btn-preset" onclick="setPreset(0.8,0.05,0.08,150)">Less Overshoot</button>
      </div>
    </div>

    <!-- Live Plot -->
    <div class="card">
      <h2>Live Plot</h2>
      <div class="chart-wrap">
        <div class="legend">
          <span class="sp">Setpoint</span>
          <span class="spd">Speed</span>
        </div>
        <canvas id="chart" width="920" height="320"></canvas>
      </div>
    </div>

    <!-- Log -->
    <div class="card">
      <h2>Serial Log</h2>
      <div class="log-box" id="logBox">Ready.<br></div>
    </div>
  </div>

<script>
/* ─── State ─── */
let ws;
let speedData = [];
let setpointData = [];
const maxPoints = 150;

const canvas = document.getElementById("chart");
const ctx = canvas.getContext("2d");

/* ─── Fixed Y axis range ─── */
const yMin = 0;
const yMax = 250;
const yStep = 50;

/* ─── Preset helper ─── */
function setPreset(kp, ki, kd, sp) {
  document.getElementById("kp").value = kp;
  document.getElementById("ki").value = ki;
  document.getElementById("kd").value = kd;
  document.getElementById("sp").value = sp;
}

/* ─── Chart drawing (white background) ─── */
function drawChart() {
  const W = canvas.width;
  const H = canvas.height;
  const pad = { top: 12, right: 15, bottom: 32, left: 48 };
  const plotW = W - pad.left - pad.right;
  const plotH = H - pad.top - pad.bottom;

  /* White background */
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, W, H);

  /* Y grid lines + labels */
  ctx.font = "11px Consolas, monospace";
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";

  for (let v = yMin; v <= yMax; v += yStep) {
    let y = pad.top + plotH - ((v - yMin) / (yMax - yMin)) * plotH;

    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(pad.left + plotW, y);
    ctx.stroke();

    ctx.fillStyle = "#64748b";
    ctx.fillText(v.toString(), pad.left - 6, y);
  }

  /* Axes border */
  ctx.strokeStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.strokeRect(pad.left, pad.top, plotW, plotH);

  /* X axis label */
  ctx.fillStyle = "#64748b";
  ctx.font = "11px Consolas, monospace";
  ctx.textAlign = "center";
  ctx.fillText("Time", pad.left + plotW / 2, H - 6);

  /* Y axis label */
  ctx.save();
  ctx.translate(13, pad.top + plotH / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("RPM", 0, 0);
  ctx.restore();

  /* Plot lines */
  plotLine(setpointData, "#d97706", 2.5, pad, plotW, plotH);
  plotLine(speedData, "#059669", 2.5, pad, plotW, plotH);
}

function plotLine(data, color, width, pad, plotW, plotH) {
  if (data.length < 2) return;

  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.beginPath();

  for (let i = 0; i < data.length; i++) {
    let x = pad.left + (i / (maxPoints - 1)) * plotW;
    let val = Math.max(yMin, Math.min(yMax, data[i]));
    let y = pad.top + plotH - ((val - yMin) / (yMax - yMin)) * plotH;

    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }

  ctx.stroke();
}

/* ─── Data update ─── */
function updateChart(d) {
  speedData.push(d.speed);
  setpointData.push(d.setpoint);

  if (speedData.length > maxPoints) speedData.shift();
  if (setpointData.length > maxPoints) setpointData.shift();

  drawChart();
}

/* ─── Log helper ─── */
function addLog(msg) {
  const box = document.getElementById("logBox");
  box.innerHTML += msg + "<br>";
  box.scrollTop = box.scrollHeight;
}

/* ─── WebSocket ─── */
function connectWS() {
  ws = new WebSocket("ws://" + location.hostname + ":81/");

  ws.onopen = () => {
    document.getElementById("status").innerText = "WebSocket connected";
    addLog("[WS] Connected");
  };

  ws.onclose = () => {
    document.getElementById("status").innerText = "Disconnected. Reconnecting...";
    addLog("[WS] Disconnected");
    setTimeout(connectWS, 1500);
  };

  ws.onmessage = (event) => {
    const d = JSON.parse(event.data);

    document.getElementById("setpointVal").innerText = d.setpoint.toFixed(1);
    document.getElementById("speedVal").innerText = d.speed.toFixed(1);
    document.getElementById("outputVal").innerText = d.output.toFixed(0);

    updateChart(d);
  };
}

function sendPID() {
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    addLog("[WS] Not connected!");
    return;
  }

  const msg = document.getElementById("kp").value + ","
            + document.getElementById("ki").value + ","
            + document.getElementById("kd").value + ","
            + document.getElementById("sp").value;
  ws.send(msg);
  addLog("[Sent] " + msg);
}

connectWS();
drawChart();
</script>
</body>
</html>
)rawliteral";